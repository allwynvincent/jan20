package com.wcd.dao;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import model.Ngo;
import model.User;
@Repository
public class UserDaoImpl implements IUserDao{
	private static final Logger logger = 			
			LoggerFactory.getLogger(UserDaoImpl.class);

	private SessionFactory sessionFactory;
private Transaction tx;
	@Autowired
	public void setSessionFactory(SessionFactory sf) {
	this.sessionFactory = sf;
	}
	
	@Override
	public void addUser(User n) {
		Session session = this.sessionFactory.openSession();
		 tx = session.beginTransaction();
		session.persist(n);
	    
		logger.info("User saved successfully, User Details="
		+ n);
		tx.commit();
		session.close();
		
	}

	@Override
	public boolean verifyUser(String email, String password) {
		Session session = this.sessionFactory.openSession();
		
		  
		  String query="from User where email=:email and password=:password";
	
		  Query q=session.createQuery(query);
		  q.setString("email", email);
		  q.setString("password", password);
		  List<User> l=q.list();
		  
if(l.size()==0)
{
	  return false;
}
session.close();
	  return true;



	}
	

	@Override
	public User getUserDetails(int userDetailsId) {
		Session session = this.sessionFactory.openSession();
		 tx = session.beginTransaction();
		System.out.println("Inside getUserDetails2");
		User p = (User) session.load(User.class, new Integer(userDetailsId));
		
		logger.info("User loaded successfully, User details=" + p);
		tx.commit();
		session.close();
		return p;
		
	}
	@Override
	public User returnUser(User n) {
		Session session = this.sessionFactory.openSession();
		 tx = session.beginTransaction();
		 String email=n.getEmail();
		 String password=n.getPassword();
		  String query="from User where email=:email and password=:password";
		  Query q=session.createQuery(query);
		  System.out.println("hii");
		  q.setString("email", email);
		  q.setString("password", password);
		  List <User> userList=q.list();
		  System.out.println("hello");
		  Iterator<User> userItr=userList.iterator();
		  User n1=new User();
		  while(userItr.hasNext())
		  {
			  n1=(User)userItr.next();
		  }
		return n1;
	}
	
}
