package com.wcd.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wcd.dao.INgoDetailDao;

import model.Ngo;
import model.NgoDetails;
@Service
public class NgoDetailServiceImpl implements INgoDetailService{
	private INgoDetailDao ngoDetDao;
	@Autowired
	public void setNgoDetDao(INgoDetailDao ngoDetDao) {
		this.ngoDetDao = ngoDetDao;
	}

	@Override
	@Transactional
	public void addNgoDet(NgoDetails n) {
		this.ngoDetDao.addNgoDet(n);
		
	}

	@Override
	@Transactional
	public void updateNgoDet(NgoDetails p) {
		this.ngoDetDao.updateNgoDet(p);
		
	}

	@Override
	@Transactional
	public List<NgoDetails> listNgoDetail() {
		
		return this.ngoDetDao.listNgoDetail();
	}

	@Override
	@Transactional
	public NgoDetails getNgoDetById(int id) {
	
		return this.ngoDetDao.getNgoDetById(id);
	}

	
	@Override
	@Transactional
	public void removeNgoDet(int id) {
		this.ngoDetDao.removeNgoDet(id);
		
	}

	@Override
	@Transactional
	public void acceptNgoDet(int id) {
		this.ngoDetDao.acceptNgoDet(id);
		
	}
	/*
	 * @Override
	 * 
	 * @Transactional public List<NgoDetails> exist(String uuid) { // TODO
	 * Auto-generated method stub return this.ngoDetDao.exist(uuid); }
	 * 
	 * @Override
	 * 
	 * @Transactional public boolean showStatusNgo(String uuid) { // TODO
	 * Auto-generated method stub return this.ngoDetDao.showStatusNgo(uuid); }
	 */

	@Override
	@Transactional
	public List<NgoDetails> listNgoByUUId(String uuid) {
		
		return this.ngoDetDao.listNgoByUuid(uuid);
	}

	

	/*
	 * @Override
	 * 
	 * @Transactional public boolean showStatusNgo(String id) {
	 * 
	 * return this.ngoDetDao.showStatusNgo(id); }
	 * 
	 * @Override
	 * 
	 * @Transactional public boolean exist(String uuid) { return
	 * this.ngoDetDao.exist(uuid);
	 * 
	 * }
	 */
}
