package com.wcd.service;

import java.util.List;

import org.springframework.stereotype.Service;

import model.Course;
import model.UserRegistration;
@Service
public interface IUserReg {
public void addUserReg(UserRegistration userReg);
public void updateUserReg(UserRegistration userReg);//update/modify
public List<UserRegistration> listUserRegDetail();//retrieve/listAll
public UserRegistration getUserRegById(int id);//search
public void removeUserReg(int id);//delete/remove
public void acceptUserReg(int id);

public List<UserRegistration> listUserByRegId(Integer userRegId);
public void attendUserReg(int id);
}
